package com.shop.product.web;
import jakarta.validation.Valid; // @Valid를 활성화(Bean Validation)
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.shop.product.domain.Product;
import com.shop.product.dto.ProductRequest;
import com.shop.product.service.ProductService;

import java.util.List;

/*
 * @RestController : 모든 핸들러 메서드 반환값을 JSON으로 직렬화(=뷰 없이 데이터 응답).
 * @RequestMapping : 공통 URL prefix 지정.
 * 메서드 매핑: @GetMapping, @PostMapping, @PutMapping, @DeleteMapping
 */
@RestController
@RequestMapping("/api/products")
@RequiredArgsConstructor
public class ProductRestController {

    private final ProductService service; // 의존성(서비스 계층)

    // C: 생성(POST /api/products)
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED) // 201
    public Product create(@RequestBody @Valid ProductRequest req){
        // @RequestBody : JSON → DTO 바인딩
        // @Valid      : DTO 필드의 검증 애노테이션 검사(@NotNull 등)
        return service.create(req);
    }

    // R: 단건(GET /api/products/{id})
    @GetMapping("/{id}")
    public Product get(@PathVariable Long id){ // URL 경로 변수 바인딩
        return service.get(id);
    }

    // R: 목록/검색(GET /api/products?keyword=데님)
    @GetMapping
    public List<Product> list(@RequestParam(required = false) String keyword){
        // @RequestParam : 쿼리스트링 파라미터 바인딩
        return service.list(keyword);
    }

    // U: 수정(PUT /api/products/{id})
    @PutMapping("/{id}")
    public Product update(@PathVariable Long id,
                          @RequestBody @Valid ProductRequest req){
        return service.update(id, req);
    }

    // D: 삭제(DELETE /api/products/{id})
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT) // 204
    public void delete(@PathVariable Long id){
        service.delete(id);
    }
}

