package com.shop.product.service;

import jakarta.transaction.Transactional; // JPA 트랜잭션(스펙)
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import com.shop.category.repository.CategoryRepository;
import com.shop.product.domain.Product;
import com.shop.product.dto.ProductRequest;
import com.shop.product.repository.ProductRepository;

import java.util.List;

/*
 * @Service : 서비스 빈 등록.
 * @RequiredArgsConstructor : final 필드에 대한 생성자 자동 → 생성자 주입.
 * @Transactional : 메서드(혹은 클래스) 단위로 DB 작업을 하나의 원자적 단위로 관리.
 *   - 예외 시 롤백, 정상 시 커밋.
 */
@Service
@RequiredArgsConstructor
@Transactional
public class ProductService {

    private final ProductRepository productRepo;
    private final CategoryRepository categoryRepo;

    // C: 생성
    public Product create(ProductRequest req){
        Category category = categoryRepo.findById(req.categoryId())
                .orElseThrow(() -> new NotFoundException("카테고리 없음"));

        Product p = Product.builder()
                .category(category)
                .name(req.name())
                .price(req.price())
                .discount(req.discount())
                .publisher(req.publisher())
                .content(req.content())
                .uploadFolder(req.uploadFolder())
                .image(req.image())
                .amount(req.amount())
                .buy(req.buy() == null ? "Y" : req.buy())
                .build();

        return productRepo.save(p); // INSERT 실행(SQL은 하이버네이트가 생성)
    }

    // R: 단건 조회
    @Transactional
    public Product get(Long id){
        return productRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("상품 없음"));
    }

    // R: 검색/목록
    @Transactional
    public List<Product> list(String keyword){
        if(keyword == null || keyword.isBlank()) return productRepo.findAll();
        return productRepo.findByNameContainingIgnoreCase(keyword);
    }

    // U: 수정
    public Product update(Long id, ProductRequest req){
        // 영속 엔티티 조회(스냅샷 관리 대상 → 더티 체킹으로 UPDATE 자동)
        Product p = get(id);
        Category category = categoryRepo.findById(req.categoryId())
                .orElseThrow(() -> new NotFoundException("카테고리 없음"));

        // 필드 변경만 하면 트랜잭션 종료 시점에 UPDATE 쿼리 자동 발생
        p.setCategory(category);
        p.setName(req.name());
        p.setPrice(req.price());
        p.setDiscount(req.discount());
        p.setPublisher(req.publisher());
        p.setContent(req.content());
        p.setUploadFolder(req.uploadFolder());
        p.setImage(req.image());
        p.setAmount(req.amount());
        if(req.buy() != null) p.setBuy(req.buy());

        return p; // save() 불필요(영속 컨텍스트가 변경 감지)
    }

    // D: 삭제
    public void delete(Long id){
        if(!productRepo.existsById(id)) throw new NotFoundException("이미 삭제되었거나 없음");
        productRepo.deleteById(id); // DELETE
    }
}
