package com.shop.product.domain;
import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
// @NotBlank, @Min 등 Bean Validation
import lombok.*;
import java.time.LocalDateTime;

import com.shop.category.domain.Category;

/*
 * 🧠 역할: 상품 테이블 매핑 + 생성/수정 자동 타임스탬프 + 기본값 처리.
 */
@Entity
@Table(name="product")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor @Builder
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // AUTO_INCREMENT
    private Long id;

    // 다대일: 여러 상품이 하나의 카테고리에 속함.
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id") // FK 이름
    private Category category;

    @NotBlank                        // 빈 문자열 금지
    @Column(nullable = false, length = 50)
    private String name;

    @NotNull @Min(0)
    @Column(nullable = false)
    private Integer price;

    @NotNull @Min(0) @Max(100)
    @Column(nullable = false)
    private Integer discount;        // 0~100%

    @NotBlank
    @Column(nullable = false, length = 50)
    private String publisher;

    @NotBlank
    @Column(nullable = false, length = 4000)
    private String content;

    @NotBlank
    @Column(nullable = false, length = 50)
    private String uploadFolder;     // 예: 2025/08/18

    @NotBlank
    @Column(nullable = false, length = 100)
    private String image;            // UUID_원본명.jpg

    @NotNull @Min(0)
    @Column(nullable = false)
    private Integer amount;          // 재고

    @Column(nullable = false, length = 1)
    private String buy;              // 'Y'/'N'

    @Column(nullable = false)
    private Integer review;          // 리뷰 수

    @Column(nullable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private LocalDateTime updatedAt;

    // ⬇️ JPA 라이프사이클 콜백: INSERT 전 한 번 호출
    @PrePersist
    public void onCreate(){
        LocalDateTime now = LocalDateTime.now();
        this.createdAt = now;
        this.updatedAt = now;
        if(this.buy == null) this.buy = "Y";  // 기본값
        if(this.review == null) this.review = 0;
    }

    // ⬇️ UPDATE 전 호출: 수정 시간 자동 반영
    @PreUpdate
    public void onUpdate(){
        this.updatedAt = LocalDateTime.now();
    }
}
