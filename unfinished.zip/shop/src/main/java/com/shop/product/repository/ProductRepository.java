package com.shop.product.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shop.category.domain.Category;

import java.util.List;

// Spring Data JPA가 구현체 자동 생성(메서드 이름으로 쿼리)
public interface ProductRepository extends JpaRepository<Category, Long> {
    List<Category> findByParentIsNull();     // 1차 카테고리
    List<Category> findByParentId(Long pid); // 특정 부모의 자식들
}
