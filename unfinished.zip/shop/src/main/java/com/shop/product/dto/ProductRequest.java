package com.shop.product.dto;

public class ProductRequest {

	public Object discount() {
		// TODO Auto-generated method stub
		return null;
	}

}
