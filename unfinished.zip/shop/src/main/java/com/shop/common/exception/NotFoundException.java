
//사용자가 요청한 자원이 없을 때 던질 커스텀 예외
package com.shop.common.exception;

public class NotFoundException extends RuntimeException {
 public NotFoundException(String message) { super(message); }
}

