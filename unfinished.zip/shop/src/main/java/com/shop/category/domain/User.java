package com.shop.category.domain;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

/*
 * @Entity : 이 클래스가 DB 테이블과 매핑되는 "엔티티"라는 표시
 * @Table  : 테이블 이름을 지정(생략 가능)
 * 로그인용으로 email(아이디), password(암호화 저장), role(권한) 사용
 */
@Entity @Table(name="users")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class User {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) // AUTO_INCREMENT
    private Long id;

    @Email @NotBlank
    @Column(nullable=false, unique=true, length=120) // 이메일 중복 금지
    private String email;

    @NotBlank
    @Column(nullable=false, length=255)
    private String password; // 평문 X, BCrypt로 해시(암호화)된 문자열 저장

    @NotBlank
    @Column(nullable=false, length=40)
    private String name;

    @Enumerated(EnumType.STRING)        // enum을 문자열로 저장(USER/ADMIN)
    @Column(nullable=false, length=20)
    private UserRole role;

    @Column(nullable=false)
    private LocalDateTime createdAt;

    @PrePersist
    void onCreate(){ this.createdAt = LocalDateTime.now(); }
}

