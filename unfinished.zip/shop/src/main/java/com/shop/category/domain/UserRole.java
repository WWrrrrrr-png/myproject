package com.shop.category.domain;


/*
 * enum: 정해진 값만 가지는 타입. (문자 오타 방지)
 * 사용 예: UserRole.USER, UserRole.ADMIN
 */
public enum UserRole {
    USER, ADMIN
}

