package com.kd.basic.product;

import org.springframework.stereotype.Service;

@Service
public class ProductService {

}
