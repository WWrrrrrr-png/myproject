package com.kd.basic.product;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProductMapper {

}
