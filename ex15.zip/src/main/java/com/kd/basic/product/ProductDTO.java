package com.kd.basic.product;

public class ProductDTO {

}
