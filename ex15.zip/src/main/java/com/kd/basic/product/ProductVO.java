package com.kd.basic.product;

public class ProductVO {

}
