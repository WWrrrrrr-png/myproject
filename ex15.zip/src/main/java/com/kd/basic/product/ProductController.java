package com.kd.basic.product;

import org.springframework.stereotype.Controller;

@Controller
public class ProductController {

}
