package com.kd.basic.user;

public class UserVO {

}
