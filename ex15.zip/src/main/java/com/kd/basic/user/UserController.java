package com.kd.basic.user;

import org.springframework.stereotype.Controller;

@Controller
public class UserController {

}
