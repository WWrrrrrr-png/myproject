package com.kd.basic.user;

import org.springframework.stereotype.Service;

@Service
public class UserService {

}
