CREATE DATABASE 데이터베이스이름
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_general_ci;
 
use 데이터베이스이름; 

-- 홈 화면의 상단 메뉴(Top/Shirts/Outer …) + 하위 카테고리(예: 맨투맨&후드).
CREATE TABLE category (
  cate_id       SMALLINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  parent_id     SMALLINT UNSIGNED NULL,     -- 상위 카테고리 (없으면 NULL)
  name          VARCHAR(50) NOT NULL,
  sort_order    SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  is_active     TINYINT(1) NOT NULL DEFAULT 1,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_category_parent
    FOREIGN KEY (parent_id) REFERENCES category(cate_id)
    ON DELETE SET NULL
    ON UPDATE CASCADE
);

CREATE INDEX idx_category_parent ON category(parent_id);
CREATE INDEX idx_category_active ON category(is_active, sort_order);

select *from category;

-- 상품리스트/상세에 보이는 핵심 정보.
CREATE TABLE product (
  product_id     INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  cate_id        SMALLINT UNSIGNED NOT NULL,
  name           VARCHAR(100) NOT NULL,
  price          INT UNSIGNED NOT NULL,          -- 정상가(원)
  discount_rate  TINYINT UNSIGNED NOT NULL DEFAULT 0,  -- 0~100(%)
  brand          VARCHAR(50) NULL,
  description    TEXT NOT NULL,                  -- 에디터 본문
  thumb_image    VARCHAR(200) NOT NULL,          -- 썸네일 파일 경로
  stock_qty      INT UNSIGNED NOT NULL DEFAULT 0, -- 재고
  is_selling     TINYINT(1) NOT NULL DEFAULT 1,  -- 판매여부
  review_count   INT UNSIGNED NOT NULL DEFAULT 0,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_product_category
    FOREIGN KEY (cate_id) REFERENCES category(cate_id)
    ON DELETE RESTRICT
    ON UPDATE CASCADE
);

CREATE INDEX idx_product_cate ON product(cate_id, is_selling, created_at);
CREATE INDEX idx_product_name ON product(name);

select  *from product; 

--  4) 상품 이미지(다중) 상세 페이지의 추가 이미지들.
CREATE TABLE product_image (
  image_id     INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  product_id   INT UNSIGNED NOT NULL,
  file_path    VARCHAR(200) NOT NULL,   -- 저장 경로(예: 2025/08/18/uuid.jpg)
  sort_order   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pimage_product
    FOREIGN KEY (product_id) REFERENCES product(product_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

CREATE INDEX idx_pimage_product ON product_image(product_id, sort_order);

select  *from product_image;

-- 회원 & 주소

CREATE TABLE `member` (
  member_id     BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  login_id      VARCHAR(30) NOT NULL UNIQUE,       -- 아이디
  password_hash CHAR(60)   NOT NULL,               -- BCrypt 등
  name          VARCHAR(30) NOT NULL,
  email         VARCHAR(80) NOT NULL UNIQUE,
  phone         VARCHAR(20) NULL,
  role          ENUM('USER','ADMIN') NOT NULL DEFAULT 'USER',
  last_login_at DATETIME NULL,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 외래키(Foreign Key, FK)란?

-- 한 테이블(자식)의 컬럼 값이, 다른 테이블(부모)의 기본키(PK) 또는 고유키(UNIQUE) 값과 반드시 일치하도록 규칙을 거는 것.

-- 즉, 테이블 간 연결(관계)을 보장하는 장치.

CREATE TABLE `address` (
  `addr_id`     BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  `member_id`   BIGINT UNSIGNED NOT NULL,
  `recipient`   VARCHAR(30) NOT NULL,
  `zipcode`     VARCHAR(10) NOT NULL,
  `addr_basic`  VARCHAR(100) NOT NULL,
  `addr_detail` VARCHAR(100) NOT NULL,
  `is_default`  TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_address_member`
    FOREIGN KEY (`member_id`)
    REFERENCES `member`(`member_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE INDEX idx_address_member ON address(member_id, is_default);

-- 주문 & 주문항목
-- 스키마 선택(있다면)
-- USE `fashion_shop`;

-- 부모 테이블들이 이미 있어야 함: `member`(혹은 `members`), `product`
-- ENGINE=InnoDB 권장

DROP TABLE IF EXISTS `order_item`;
DROP TABLE IF EXISTS `orders`;

CREATE TABLE `orders` (
  `order_id`        BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  `member_id`       BIGINT UNSIGNED NOT NULL,
  `order_no`        VARCHAR(30) NOT NULL UNIQUE,      -- 화면 표시용
  `status`          ENUM('PAY_PENDING','PAID','PREPARING','SHIPPED','CANCELLED','REFUNDED')
                    NOT NULL DEFAULT 'PAY_PENDING',
  `total_price`     INT UNSIGNED NOT NULL,            -- 할인/쿠폰 적용 후 결제금액
  `receiver_name`   VARCHAR(30) NOT NULL,
  `receiver_phone`  VARCHAR(20) NOT NULL,
  `recv_zipcode`    VARCHAR(10) NOT NULL,
  `recv_addr_basic` VARCHAR(100) NOT NULL,
  `recv_addr_detail` VARCHAR(100) NOT NULL,
  `requested_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 주문 시각
  `paid_at`         DATETIME NULL,
  CONSTRAINT `fk_orders_member`
    FOREIGN KEY (`member_id`)
    REFERENCES `member`(`member_id`)   -- ← 예약어라서 백틱 필수!
    ON DELETE RESTRICT
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- FK가 member_id에 인덱스를 자동으로 만들지만,
-- 조회(회원별 주문 + 정렬) 성능을 위해 복합 인덱스 추가(이름 충돌 주의)
CREATE INDEX `idx_orders_member` ON `orders`(`member_id`, `requested_at`);

CREATE TABLE `order_item` (
  `order_item_id` BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  `order_id`      BIGINT UNSIGNED NOT NULL,
  `product_id`    INT UNSIGNED NOT NULL,
  `product_name`  VARCHAR(100) NOT NULL,  -- 스냅샷(주문 시점의 이름)
  `unit_price`    INT UNSIGNED NOT NULL,  -- 스냅샷(할인 반영 단가)
  `qty`           INT UNSIGNED NOT NULL,
  CONSTRAINT `fk_oitem_order`
    FOREIGN KEY (`order_id`)
    REFERENCES `orders`(`order_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_oitem_product`
    FOREIGN KEY (`product_id`)
    REFERENCES `product`(`product_id`)
    ON DELETE RESTRICT
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX `idx_oitem_order` ON `order_item`(`order_id`);

select *from `order_item`;

-- 리뷰 

DROP TABLE IF EXISTS `review`;

CREATE TABLE `review` (
  `review_id`   BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  `product_id`  INT UNSIGNED NOT NULL,
  `member_id`   BIGINT UNSIGNED NOT NULL,
  `rating`      TINYINT UNSIGNED NOT NULL,            -- 1~5
  `title`       VARCHAR(100) NOT NULL,
  `content`     TEXT NOT NULL,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

  -- FK 요건을 만족(선행 인덱스) + 조회 정렬 성능을 위해 복합 인덱스 먼저 선언
  KEY `idx_review_product` (`product_id`, `created_at`),
  KEY `idx_review_member`  (`member_id`, `created_at`),

  CONSTRAINT `fk_review_product`
    FOREIGN KEY (`product_id`) REFERENCES `product`(`product_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,

  CONSTRAINT `fk_review_member`
    FOREIGN KEY (`member_id`)  REFERENCES `member`(`member_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;









