package com.shop.category.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity                     // JPA 엔티티(테이블과 1:1 매핑됨)
@Table(name = "category")   // 테이블명 지정(기본은 클래스명 소문자)
@Getter @Setter             // 롬복: 게터/세터 자동 생성
@NoArgsConstructor          // 기본 생성자 자동
@AllArgsConstructor
@Builder                    // 빌더 패턴 생성기(가독성 좋은 생성)
public class Category {

    @Id                     // PK(기본키)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;        // AUTO_INCREMENT

    @Column(nullable = false, length = 50) // NOT NULL, 길이 제한
    private String name;

    // 부모 카테고리(최상위는 null). 다대일(여러 자식 → 한 부모)
    @ManyToOne(fetch = FetchType.LAZY) // 지연로딩: 필요할 때 쿼리
    @JoinColumn(name = "parent_id")    // FK 컬럼명
    private Category parent;

	public static Object builder() {
		// TODO Auto-generated method stub
		return null;
	}
}
