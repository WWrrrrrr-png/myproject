package com.shop.category.service;



import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import com.shop.category.domain.Category;
import com.shop.category.repository.CategoryRepository;

import java.util.List;

/*
 * 🧠 역할: 도메인 규칙(비즈니스 로직) + 트랜잭션 경계(여기선 단순해서 생략 가능).
 * @Service : 서비스 빈 등록. 컨트롤러 ↔ 레포지토리 사이에서 로직 담당.
 * @RequiredArgsConstructor : final 필드에 대해 생성자 자동 생성(생성자 주입).
 */
@Service
@RequiredArgsConstructor
public class CategoryService {

    private final CategoryRepository repo; // 의존성(저장소)

    public Category create(String name, Long parentId){
        Category parent = (parentId == null) ? null
                : repo.findById(parentId).orElseThrow(() -> new RuntimeException("parent not found"));
        return repo.save(Category.builder().name(name).parent(parent).build()); // INSERT
    }

    public List<Category> parents(){ return repo.findByParentIsNull(); }
    public List<Category> children(Long parentId){ return repo.findByParentId(parentId); }
}



