package com.shop.category.repository;

 // 📦 패키지 선언 (폴더 경로와 같아야 함)

import org.springframework.data.jpa.repository.JpaRepository; // 🧪 스프링 데이터 JPA 리포지토리

import com.shop.category.domain.Category;

import java.util.List;

/**
 * 🧪 인터페이스(구현 없음)
 * - 우리가 직접 구현 클래스를 만들지 않는다.
 * - Spring Data JPA가 이 인터페이스를 보고 런타임에 "구현체"를 자동 생성해서 빈으로 등록한다.
 *
 * extends JpaRepository<Category, Long>
 *  - 첫 번째 제네릭: 엔티티 타입 (Category)
 *  - 두 번째 제네릭: 기본키 타입 (Long)
 *  - 기본 CRUD 메서드가 이미 제공됨: save, findById, findAll, deleteById ...
 */
public interface CategoryRepository extends JpaRepository<Category, Long> {

    // 🔍 파생 쿼리 메서드: 메서드 이름만으로 WHERE 절을 만들어 준다.
    // 부모가 없는 최상위(1차) 카테고리 목록
    List<Category> findByParentIsNull();

    // 특정 부모 id 를 가진 자식(2차) 카테고리 목록
    List<Category> findByParentId(Long pid);
}
