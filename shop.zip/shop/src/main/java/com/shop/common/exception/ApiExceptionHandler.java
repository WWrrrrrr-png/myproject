package com.shop.common.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;

@RestControllerAdvice // 모든 @RestController 대상 전역 예외 처리기
public class ApiExceptionHandler {

    @ExceptionHandler(NotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND) // HTTP 404로 내려보내기
    public Map<String, Object> handleNotFound(NotFoundException e) {
        return Map.of(
            "timestamp", LocalDateTime.now(),
            "status", 404,
            "error", "Not Found",
            "message", e.getMessage()
        );
    }
}