package com.shop.product.dto;

import jakarta.validation.constraints.*;

/*
 * 🧠 ProductRequest DTO (record)
 * - Controller → Service 로 들어오는 요청 데이터 상자(불변)
 * - record는 각 필드명과 동일한 이름의 "접근자 메서드"가 자동 생성됨
 *   예) price() / discountRate() / stockQty() ...
 * - setter가 없으므로 수정 용도 X, 입력 검증용으로 사용
 */
public record ProductRequest(
        @NotNull Long categoryId,           // FK: 카테고리 ID
        @NotBlank String name,              // 상품명
        @NotNull @Min(0) Integer price,     // 가격(원)
        @NotNull @Min(0) @Max(100) Integer discountRate, // 할인율(%)
        String brand,                       // 브랜드(선택)
        @NotBlank String description,       // 설명
        @NotBlank String thumbImage,        // 썸네일 경로/파일
        @NotNull @Min(0) Integer stockQty,  // 재고 수량
        Boolean selling                     // 판매 여부(null이면 기본 true 처리)
) {}
