package com.shop.product.service;

import com.shop.category.domain.Category;                // 카테고리 엔티티
import com.shop.category.repository.CategoryRepository; // 카테고리 레포지토리
import com.shop.common.exception.NotFoundException;     // 커스텀 예외
import com.shop.product.domain.Product;                 // 상품 엔티티
import com.shop.product.dto.ProductRequest;             // 요청 DTO(record)
import com.shop.product.repository.ProductRepository;   // 상품 레포지토리
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // ★ 스프링 트랜잭션
import java.util.List;

/*
 * @Service : 서비스 계층 컴포넌트(스프링 빈 등록)
 * @RequiredArgsConstructor : final 필드 생성자 자동 생성(생성자 주입)
 * @Transactional(readOnly = true)
 *   - 기본은 읽기 전용 트랜잭션(성능 최적화: 플러시/더티체킹 최소화)
 *   - 쓰기 메서드(C/U/D)에서만 별도 @Transactional로 덮어씀
 */
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class ProductService {

    private final ProductRepository productRepo;
    private final CategoryRepository categoryRepo;

    // CREATE: 쓰기 → 별도 트랜잭션(읽기전용 해제)
    @Transactional
    public Product create(ProductRequest req){
        // FK 유효성 체크: 존재하는 카테고리인지 확인
        Category category = categoryRepo.findById(req.categoryId())
                .orElseThrow(() -> new NotFoundException("카테고리 없음"));

        // 빌더 패턴으로 엔티티 생성
        Product p = Product.builder()
                .category(category)
                .name(req.name())
                .price(req.price())
                .discountRate(req.discountRate())
                .brand(req.brand())
                .description(req.description())
                .thumbImage(req.thumbImage())
                .stockQty(req.stockQty())
                .selling(req.selling() == null ? true : req.selling()) // 기본값 처리
                .build();

        return productRepo.save(p); // INSERT
    }

    // READ one: 읽기 전용(기본 트랜잭션 사용)
    public Product get(Long id){
        return productRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("상품 없음"));
    }

    // READ list: 키워드 없으면 전체, 있으면 like 검색
    public List<Product> list(String keyword){
        if (keyword == null || keyword.isBlank()) return productRepo.findAll();
        return productRepo.findByNameContainingIgnoreCase(keyword);
    }

    // UPDATE: 쓰기 → 별도 트랜잭션
    @Transactional
    public Product update(Long id, ProductRequest req){
        // 1) 대상 엔티티 조회(영속 상태 → 더티체킹 대상)
        Product p = get(id);

        // 2) FK 검증(카테고리 존재 확인)
        Category category = categoryRepo.findById(req.categoryId())
                .orElseThrow(() -> new NotFoundException("카테고리 없음"));

        // 3) 필드 변경(커밋 시점에 변경감지로 UPDATE 자동 실행)
        p.setCategory(category);
        p.setName(req.name());
        p.setPrice(req.price());
        p.setDiscountRate(req.discountRate());
        p.setBrand(req.brand());
        p.setDescription(req.description());
        p.setThumbImage(req.thumbImage());
        p.setStockQty(req.stockQty());
        if (req.selling() != null) p.setSelling(req.selling());

        return p; // save() 불필요: 영속 엔티티의 더티체킹
    }

    // DELETE: 쓰기 → 별도 트랜잭션
    @Transactional
    public void delete(Long id){
        if (!productRepo.existsById(id)) throw new NotFoundException("이미 삭제되었거나 없음");
        productRepo.deleteById(id); // DELETE
    }
}
