package com.shop.product.domain;

import jakarta.persistence.*;                 // JPA(Entity, Table, Column 등 매핑용) 어노테이션 모음
import jakarta.validation.constraints.*;     // Bean Validation(@NotBlank, @Min 등 검증용) 어노테이션 모음
import lombok.*;                             // Lombok(@Getter, @Setter 등 자동 코드 생성)
import java.time.LocalDateTime;

import com.shop.category.domain.Category;    // Category 엔티티와 연관관계 매핑용

/*
 * 🧠 역할: DB product 테이블과 매핑되는 상품 엔티티
 * - 각 필드는 DB 컬럼과 매핑
 * - @PrePersist/@PreUpdate로 생성/수정 시간 자동 반영
 */
 //@Entity : 해당 클래스가 JPA 엔티티(테이블과 매핑되는 클래스)임을 선언
@Entity
 //@Table : 어떤 테이블과 매핑되는지 지정 (여기서는 product 테이블)
@Table(name = "product")
 //@Getter : 모든 필드에 대한 getter 메서드 자동 생성
@Getter 
 //@Setter : 모든 필드에 대한 setter 메서드 자동 생성
@Setter 
 //@NoArgsConstructor : 파라미터 없는 기본 생성자 자동 생성
@NoArgsConstructor 
 //@AllArgsConstructor : 모든 필드를 파라미터로 받는 생성자 자동 생성
@AllArgsConstructor 
 //@Builder : 빌더 패턴 메서드 자동 생성 (선택적 생성자처럼 사용 가능)
@Builder 
public class Product {

    //@Id : 이 필드가 테이블의 기본키(PK)임을 표시
    @Id
    //@GeneratedValue : PK를 자동 생성하는 전략. IDENTITY → DB의 AUTO_INCREMENT 사용
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    //@Column : 자바 필드와 DB 컬럼(product_id) 매핑
    @Column(name = "product_id")
    private Long id;

    //@ManyToOne : 다대일(N:1) 관계 설정 (여러 상품 → 하나의 카테고리)
    //@fetch = LAZY : 지연 로딩. 상품만 조회할 때는 카테고리 쿼리를 즉시 실행하지 않음
    @ManyToOne(fetch = FetchType.LAZY)
    //@JoinColumn : 외래키(FK) 컬럼 이름 지정 (product.cate_id → category.cate_id 참조)
    @JoinColumn(name = "cate_id", nullable = false)
    private Category category;

    //@NotBlank : 값이 null/빈문자/공백이면 안 됨
    //@Column : DB name 컬럼과 매핑, 최대 길이 100, null 금지
    @NotBlank
    @Column(name = "name", nullable = false, length = 100)
    private String name;

    //@NotNull : null 값 불가
    //@Min(0) : 최소값 0 이상
    //@Column : price 컬럼 매핑, null 금지
    @NotNull @Min(0)
    @Column(name = "price", nullable = false)
    private Integer price;

    //@NotNull : null 값 불가
    //@Min(0), @Max(100) : 0~100 범위 제한
    //@Column : discount_rate 컬럼과 매핑
    @NotNull @Min(0) @Max(100)
    @Column(name = "discount_rate", nullable = false)
    private Integer discountRate;

    //@Column : brand 컬럼과 매핑. null 허용, 최대 50자
    @Column(name = "brand", length = 50)
    private String brand;

    //@NotBlank : null/빈문자/공백 허용 안 함
    //@Column : description 컬럼과 매핑, TEXT 타입(긴 문자열 저장)
    @NotBlank
    @Column(name = "description", nullable = false, columnDefinition = "TEXT")
    private String description;

    //@NotBlank : null/빈문자/공백 금지
    //@Column : thumb_image 컬럼과 매핑, 최대 200자
    @NotBlank
    @Column(name = "thumb_image", nullable = false, length = 200)
    private String thumbImage;

    //@NotNull : null 금지
    //@Min(0) : 최소값 0
    //@Column : stock_qty 컬럼과 매핑
    @NotNull @Min(0)
    @Column(name = "stock_qty", nullable = false)
    private Integer stockQty;

    //@Column : is_selling 컬럼과 매핑. tinyint(1) → 자바 Boolean
    @Column(name = "is_selling", nullable = false)
    private Boolean selling;

    //@NotNull : null 금지
    //@Min(0) : 최소값 0
    //@Column : review_count 컬럼과 매핑
    @NotNull @Min(0)
    @Column(name = "review_count", nullable = false)
    private Integer reviewCount;

    //@Column : created_at 컬럼과 매핑 (생성 시각)
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    //@Column : updated_at 컬럼과 매핑 (수정 시각)
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    // ---------- 엔티티 라이프사이클 콜백 ----------
    //@PrePersist : 엔티티가 INSERT 되기 "직전"에 실행되는 메서드
    @PrePersist
    public void onCreate() {
        // LocalDateTime.now() : 현재 시간 불러오기 (static 메서드 호출)
        LocalDateTime now = LocalDateTime.now(); 

        // this : "현재 객체 자기 자신"을 가리킴
        // this.createdAt = now; → 현재 Product 객체의 createdAt 필드에 now를 대입
        this.createdAt = now;  // 생성일시 채우기

        // this.updatedAt = now; → 현재 Product 객체의 updatedAt 필드에 now 대입
        this.updatedAt = now;  // 수정일시도 동일하게 세팅

        // if (this.selling == null) → 아직 값이 없으면
        // this.selling = true; → 기본값 true로 설정
        if (this.selling == null) this.selling = true;      

        // if (this.reviewCount == null) → 아직 값이 없으면
        // this.reviewCount = 0; → 기본값 0으로 설정
        if (this.reviewCount == null) this.reviewCount = 0; 
    }

    //@PreUpdate : 엔티티가 UPDATE 되기 "직전"에 실행되는 메서드
    @PreUpdate
    public void onUpdate() {
        // this.updatedAt = LocalDateTime.now(); → 수정할 때마다 updatedAt 필드를 현재 시간으로 갱신
        this.updatedAt = LocalDateTime.now();    
    }



	
}
